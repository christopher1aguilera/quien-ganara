const getusu = () =>{
    return Axios.get('https://randomuser.me/api')
         .then(response => response.data.results[0])
}

const enviar = require('./mailer')
const { default: Axios } = require("axios")
const http = require('http')
const fs = require('fs')
const { v4: uuidv4 } = require('uuid')
http
.createServer(function (req, res) {
let datausuarioJSON = JSON.parse(fs.readFileSync("usuarios.json", "utf8"));
let datapremioJSON = JSON.parse(fs.readFileSync("premio.json", "utf8"));
let usuarios = datausuarioJSON.usuarios;
let correos = []
correos.push('christopher.aguilera.mad@gmail.com')
usuarios.forEach(element => {
    correos.push(element.correo)
});
if (req.url.startsWith('/') && req.method == "GET") {
res.setHeader('content-type', 'text/html')
fs.readFile('index.html', 'utf8', (err, data) => {
res.end(data)
})
}
if ((req.url == '/usuario') && req.method == "POST") {
    getusu().then(datos =>{
        let nombre = `${datos.name.title} ${datos.name.first} ${datos.name.last}`
        let correo = `${datos.email}`
        correos = `${correos},${correo}`
        let pais = `${datos.location.country}`
        let imagen = `${datos.picture.thumbnail}`
        let ID = uuidv4().slice(0, 6)
        let info = {nombre: nombre, foto: imagen, pais: pais, correo: correo, id: ID}
        usuarios.push(info);
        fs.writeFileSync("usuarios.json",JSON.stringify(datausuarioJSON));
        res.end();
    });         
}
if (req.url.startsWith('/usuarios') && req.method == "GET") {
res.end(JSON.stringify(datausuarioJSON));
}
if (req.url.startsWith('/premio') && req.method == "GET") {
res.end(JSON.stringify(datapremioJSON));
}
if (req.url.startsWith('/premio') && req.method == "PUT") {
    let body;
    req.on("data", (payload) => {
    body = JSON.parse(payload);
        });
    req.on("end", () => {
        fs.writeFileSync("premio.json", JSON.stringify(body));
        res.end();
    });
}
if (req.url.startsWith('/ganador') && req.method == "GET") {
const random = Math.floor(Math.random() * (usuarios.length-1));
let ganador = usuarios[random]
var myString = JSON.stringify(ganador);
res.writeHead(200, { 'Content-Type': 'application/json' })
let mensaje = `El ganador de ¿Quien ganara? fue ${ganador.nombre}, gracias a todos por participar`
enviar(correos, mensaje)
res.end(myString)
}
})
.listen(3000, () => console.log('Escuchando el puerto 3000'))